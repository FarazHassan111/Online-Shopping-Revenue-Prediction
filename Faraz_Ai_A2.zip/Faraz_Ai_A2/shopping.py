import csv
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier

# Portion of data to reserve for testing
TEST_SIZE = 0.4

# Mapping month names to integers
MONTHS = {
    "Jan": 0, "Feb": 1, "Mar": 2, "Apr": 3, "May": 4,
    "June": 5, "Jul": 6, "Aug": 7, "Sep": 8, "Oct": 9,
    "Nov": 10, "Dec": 11
}

def main():
    """
    Main program execution:
    1. Load the shopping data
    2. Split into training and test sets
    3. Train a k-nearest neighbor model
    4. Make predictions on the test set
    5. Evaluate sensitivity and specificity
    6. Print results
    """

    # Automatically use shopping.csv in the same folder
    filename = "shopping.csv"

    # Load data from CSV
    evidence, labels = load_data(filename)

    # Split data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(
        evidence, labels, test_size=TEST_SIZE
    )

    # Train the KNN model
    model = train_model(X_train, y_train)

    # Make predictions on the test set
    predictions = model.predict(X_test)

    # Evaluate sensitivity and specificity
    sensitivity, specificity = evaluate(y_test, predictions)

    # Calculate correct and incorrect predictions
    correct = sum(1 for actual, pred in zip(y_test, predictions) if actual == pred)
    incorrect = len(y_test) - correct

    # Print results
    print(f"Correct: {correct}")
    print(f"Incorrect: {incorrect}")
    print(f"True Positive Rate: {100 * sensitivity:.2f}%")
    print(f"True Negative Rate: {100 * specificity:.2f}%")


def load_data(filename):
    """
    Load shopping data from a CSV file and convert into:
    - evidence: list of lists, each containing 17 features
    - labels: list of integers, 1 if Revenue is TRUE, 0 otherwise
    """

    evidence = []
    labels = []

    # Open CSV file
    with open(filename) as f:
        reader = csv.DictReader(f)

        for row in reader:
            # Convert each column to proper type
            row_evidence = [
                int(row["Administrative"]),
                float(row["Administrative_Duration"]),
                int(row["Informational"]),
                float(row["Informational_Duration"]),
                int(row["ProductRelated"]),
                float(row["ProductRelated_Duration"]),
                float(row["BounceRates"]),
                float(row["ExitRates"]),
                float(row["PageValues"]),
                float(row["SpecialDay"]),
                MONTHS[row["Month"]],
                int(row["OperatingSystems"]),
                int(row["Browser"]),
                int(row["Region"]),
                int(row["TrafficType"]),
                1 if row["VisitorType"] == "Returning_Visitor" else 0,
                1 if row["Weekend"] == "TRUE" else 0
            ]

            # Append to evidence
            evidence.append(row_evidence)

            # Convert Revenue to label
            labels.append(1 if row["Revenue"] == "TRUE" else 0)

    return evidence, labels


def train_model(evidence, labels):
    """
    Train a k-nearest neighbor model (k=1) on the provided evidence and labels.
    Returns the fitted KNN model.
    """

    model = KNeighborsClassifier(n_neighbors=1)
    model.fit(evidence, labels)
    return model


def evaluate(labels, predictions):
    """
    Calculate sensitivity (true positive rate) and specificity (true negative rate)
    given the actual labels and predicted labels.

    Returns a tuple: (sensitivity, specificity)
    """

    true_positive = sum(1 for actual, pred in zip(labels, predictions) if actual == 1 and pred == 1)
    false_negative = sum(1 for actual, pred in zip(labels, predictions) if actual == 1 and pred == 0)
    true_negative = sum(1 for actual, pred in zip(labels, predictions) if actual == 0 and pred == 0)
    false_positive = sum(1 for actual, pred in zip(labels, predictions) if actual == 0 and pred == 1)

    sensitivity = true_positive / (true_positive + false_negative)
    specificity = true_negative / (true_negative + false_positive)

    return sensitivity, specificity


if __name__ == "__main__":
    main()
